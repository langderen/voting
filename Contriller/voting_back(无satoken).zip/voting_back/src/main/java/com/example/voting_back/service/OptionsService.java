package com.example.voting_back.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.voting_back.entity.Options;

public interface OptionsService extends IService<Options> {

}
