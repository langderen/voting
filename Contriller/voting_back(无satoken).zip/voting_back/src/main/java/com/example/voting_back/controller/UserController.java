package com.example.voting_back.controller;


import com.example.voting_back.common.Result;
import com.example.voting_back.entity.User;
import com.example.voting_back.service.UserService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {
    @Resource
    private UserService userService;

    /*
    * 新建用户*/
    @PostMapping
    public Result addUser(@RequestBody User user) {
        return Result.success(userService.save(user));
    }
    /*
     * 通过id修改用户
     * */

    @PutMapping
    public  Result updateUser(@RequestBody User user){

        return Result.success(userService.updateById(user));
    }
    /*
    *通过用户id查询用户
    * @param id
    * @return
    */

    @GetMapping("/{id}")
    public Result getUserById(@PathVariable Long id) {
        return Result.success(userService.getOptById(id));
    }

    @DeleteMapping("/{id}")
    public Result deletePoll(@PathVariable Long id){
        return Result.success(userService.removeById(id));
    }


}
