package com.example.voting_back.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.voting_back.entity.Votes;

public interface VotesService extends IService<Votes> {

}
